<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Music school</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="container">
<div class="flex-container">
<header>
  <div id="top">
      <h1 id="websiteTitle">Music School</h1>
      </div><!--top-->
      <div class="navigation">
          <div><a href="index.php">Home</a></div>
          <div><a href="pages/about.php">About</a></div>
		  <div><a href="pages/contact.php">Contact</a></div>
          </div> 
</header>