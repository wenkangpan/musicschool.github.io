<?php
        session_start();
        $sessionID=session_id();
?>		