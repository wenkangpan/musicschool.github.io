<?php
    include "../modules/session.php";
	include "../modules/database.php";
    include "../modules/sanitize.php";
	include "headerPage.php";
    include "registerTeacherBody.php";
	include "footer.php";
?>




