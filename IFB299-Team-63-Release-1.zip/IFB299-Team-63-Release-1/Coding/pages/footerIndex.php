<div id="mainimage">
<img src="images/music_main.jpg" alt="Music school">
</div><!--mainimage-->
<footer>copyright</footer><!--footer-->
</div><!--flex-container-->
</div><!--containner-->

</body>
</html>
